# TASKWEAVE — AI Agent Economy

TASKWEAVE turns a project brief into a priced workflow. Groq generates the proposed task breakdown; Django validates agent assignments and calculates the quote from database prices. The user approves the plan, then pays through **PayPal Sandbox**. The server verifies the returned order and capture before marking the payment as captured.

> **Prototype status:** AI requirement-based planning, task-to-agent assignment, database pricing, budget checks, plan approval, PayPal Sandbox checkout/capture verification, and paid-task execution via Groq-generated Markdown deliverables are included. Execution is synchronous and text-based; it is not a secure production agent runtime and does not invoke external specialist tools or deploy applications.

## Stack

- Python / Django
- SQLite
- Groq API (`openai/gpt-oss-120b`) for planning
- PayPal Orders v2 API — Sandbox only
- HTML, CSS, JavaScript

## Requirements

- Python 3.11+
- A Groq API key (free tier availability and rate limits are controlled by Groq)
- PayPal Developer account with Sandbox Business and Personal test accounts
- Internet access for Groq and PayPal Sandbox calls

## Windows setup (PowerShell)

```powershell
cd path\to\TASKWEAVE
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

Open `.env` and set `GROQ_API_KEY`, `PAYPAL_CLIENT_ID`, and `PAYPAL_CLIENT_SECRET` using credentials from the PayPal **Sandbox** app. Keep `.env` private; never commit it.

Generate a Django secret key for `DJANGO_SECRET_KEY` (for example, use Python's `secrets.token_urlsafe(48)`), then run:

```powershell
python manage.py migrate
python manage.py seed_agents
python manage.py createsuperuser
python manage.py check
python manage.py runserver
```

Open http://127.0.0.1:8000/ and use **Workspace**.

## PayPal Sandbox test

1. Create a Sandbox REST app in the PayPal Developer Dashboard.
2. Put that app's Sandbox Client ID and Secret in `.env`.
3. Create/use a Sandbox Personal buyer account and a Sandbox Business merchant account.
4. Generate a task plan and approve it.
5. Select **Continue to PayPal Sandbox**.
6. Sign in as the Sandbox Personal buyer and complete the checkout.
7. PayPal returns to `/paypal/return/`. TASKWEAVE retrieves the order from PayPal, captures only when the order is `APPROVED`, checks the order/capture status and compares amount/currency against the saved server-side quote.
8. After capture verification, use **Execute paid tasks** to run each assigned specialist task. Completed Markdown deliverables can be downloaded individually.

Do not manually capture the same order in a separate workflow while also using the browser return handler. If an order remains `PAYER_ACTION_REQUIRED`, the buyer approval has not been completed for that order. Use the same order's buyer-action URL and inspect the PayPal Sandbox order before retrying. Do not infer payment success from the buyer account's transaction list alone.

## Pricing and trust boundaries

- AI output contains task descriptions and agent names only.
- The backend rejects unknown agent assignments.
- Task prices are read from active `Agent` database records, not from AI output or browser input.
- The optional budget is checked server-side after pricing.
- PayPal amount/currency are derived from the saved plan quote.
- Payment is marked `CAPTURED` only after server-side PayPal verification.

## Important prototype limitations

- This is a hackathon prototype, not production payment software.
- There is no user authentication or plan ownership model yet. Do not expose this instance publicly with real customer data or real payments.
- PayPal Sandbox only; no live-payment credentials.
- Specialist execution currently uses Groq to produce text/Markdown work products. It does not run generated code, access user databases, deploy applications, or call domain-specific external tools.
- Execution runs synchronously in the web request; long plans may exceed web-server timeouts. A durable queue, retries, and idempotent execution records are needed for production.
- No webhook reconciliation or automated end-to-end PayPal tests are included.
- No user authentication or plan ownership model exists. Anyone who can reach the demo instance may interact with plan endpoints; keep it local or behind access controls.
- Requirement coverage is structurally validated, but semantic completeness still requires human review.
- Localhost return URLs are for local development. Public demos need a stable HTTPS URL and matching PayPal app configuration.
- `db.sqlite3`, `.env`, virtual environments, and local secrets are intentionally excluded from the source package.

## Admin

Use the Django superuser at `/admin/` to manage specialist agents and inspect plans/payments. Run `python manage.py seed_agents` to create/update the three demo specialists:

| Specialist | Capability | Price |
|---|---|---:|
| Data Analyst | Data Analysis | $5.00 |
| Visualization Specialist | Data Visualization | $3.00 |
| Report Writer | Report Generation | $4.00 |

## GitHub checklist

Before publishing:
- Confirm `.env` is not staged (`git status`).
- Add a repository URL to this README.
- Keep the MIT license.
- Include a short demo video and hackathon submission description.
- Do not publish Sandbox credentials, real credentials, buyer account passwords, or transaction checkout URLs.
